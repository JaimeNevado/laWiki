from pymongo import MongoClient

client = MongoClient("mongodb+srv://admin:1234@cluster0.lgrl8.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

db = client.todo_db

collection_name = db["todo_collection"]
