from sqlite3 import Date
from pydantic import BaseModel

class Article(BaseModel):
    name: str
    text: str
    attachedFiles: str
    author : str
    images : str
    googleMaps : str
    date : str


